# VORTEX BULK VHF Alarm — Android

Offline Android wrapper and native monitoring service for the VORTEX BULK VHF
sector assistant.

## Build

Requirements: Java 17, Android SDK 35/build-tools 35.0.0, and Gradle 8.9.

```bash
gradle :app:testDebugUnitTest :app:assembleDebug --no-daemon
```

The bundled operator page must be placed at:

```text
app/src/main/assets/index.html
```

The page is loaded only from `file:///android_asset/`; external navigation and
network subresources are blocked. The manifest intentionally has no `INTERNET`,
`ACCESS_BACKGROUND_LOCATION`, or boot permission.

## Operational limitation

This application is a bridge-team aid, not a replacement for corrected charts,
ECDIS, publications, continuous VHF watch, or live VTS instructions. The officer
must acknowledge the alarm and separately confirm completion of every call.

# The JavaScript interface is referenced by name from the bundled offline page.
-keepclassmembers class com.vortexbulk.vhf.VhfBridge {
    @android.webkit.JavascriptInterface <methods>;
}

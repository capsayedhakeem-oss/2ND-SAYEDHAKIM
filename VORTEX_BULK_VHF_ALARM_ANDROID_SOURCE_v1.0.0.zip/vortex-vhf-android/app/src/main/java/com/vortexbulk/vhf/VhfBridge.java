package com.vortexbulk.vhf;

import android.Manifest;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.media.AudioManager;
import android.os.Build;
import android.provider.Settings;
import android.webkit.JavascriptInterface;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public final class VhfBridge {
    private static final String BRIDGE_PREFS_NAME = "vortex_vhf_bridge_data";
    private static final String KEY_BRIDGE_DATA = "report_data_json";
    private static final int MAX_BRIDGE_JSON_LENGTH = 16_384;
    private static final int EVENT_COUNT = 4;
    private static final long SNAPSHOT_STALE_MS = 15_000L;

    private static final Set<String> REPORT_KEYS = Collections.unmodifiableSet(
            new HashSet<>(Arrays.asList(
                    "shipName",
                    "callSign",
                    "imo",
                    "mmsi",
                    "draftFwd",
                    "draftAft",
                    "airDraft",
                    "trueCourse",
                    "lastPort",
                    "portOfCall",
                    "nextPort",
                    "eta",
                    "heightChanged",
                    "pbg",
                    "movementRequest",
                    "pilotBooking",
                    "pilotTime",
                    "condition",
                    "cargo",
                    "dangerousCargo",
                    "pob",
                    "crew",
                    "passengers",
                    "pilotOnBoard",
                    "armedGuards",
                    "weapons",
                    "securityLevel",
                    "defects",
                    "pollution"
            ))
    );

    private final MainActivity activity;
    private final SharedPreferences bridgePreferences;
    private final SharedPreferences servicePreferences;

    public VhfBridge(MainActivity activity) {
        this.activity = activity;
        this.bridgePreferences = activity.getSharedPreferences(
                BRIDGE_PREFS_NAME,
                Context.MODE_PRIVATE
        );
        this.servicePreferences = activity.getSharedPreferences(
                VhfMonitorService.PREFS_NAME,
                Context.MODE_PRIVATE
        );
    }

    @JavascriptInterface
    public String getSnapshot() {
        String snapshot = servicePreferences.getString(
                VhfMonitorService.KEY_SNAPSHOT_JSON,
                ""
        );
        if (snapshot == null || snapshot.isEmpty()) {
            return buildBootstrapSnapshot();
        }
        try {
            JSONObject root = new JSONObject(snapshot);
            long updatedAtMs = root.optLong("updatedAtMs", 0L);
            boolean stale = root.optBoolean("armRequested", false)
                    && (updatedAtMs <= 0L
                    || System.currentTimeMillis() - updatedAtMs > SNAPSHOT_STALE_MS);
            if (stale) {
                root.put("serviceRunning", false);
                root.put("armed", false);
                root.put("canArm", false);
                root.put("gpsStatus", "STALE");
                root.put("stage", "GPS_DEGRADED");
                root.put("statusMessage", "MONITOR SERVICE NOT RESPONDING \u2014 REOPEN APP / CHECK GPS");
                root.put("alarmActive", false);
            }
            return root.toString();
        } catch (JSONException malformedSnapshot) {
            return buildBootstrapSnapshot();
        }
    }

    @JavascriptInterface
    public void arm() {
        sendServiceCommand(VhfMonitorService.ACTION_ARM, true);
    }

    @JavascriptInterface
    public void startMonitoring() {
        arm();
    }

    @JavascriptInterface
    public void disarm() {
        sendServiceCommand(VhfMonitorService.ACTION_DISARM, false);
    }

    @JavascriptInterface
    public void stopMonitoring() {
        disarm();
    }

    @JavascriptInterface
    public void silenceAlarm() {
        sendServiceCommand(VhfMonitorService.ACTION_ACKNOWLEDGE, false);
    }

    @JavascriptInterface
    public void acknowledgeAlarm() {
        silenceAlarm();
    }

    @JavascriptInterface
    public void acknowledge() {
        silenceAlarm();
    }

    @JavascriptInterface
    public void completeCurrentEvent() {
        sendServiceCommand(VhfMonitorService.ACTION_COMPLETE, false);
    }

    @JavascriptInterface
    public void completeEvent() {
        completeCurrentEvent();
    }

    @JavascriptInterface
    public void testAlarm() {
        sendServiceCommand(VhfMonitorService.ACTION_TEST_ALARM, false);
    }

    @JavascriptInterface
    public void soundTest() {
        testAlarm();
    }

    @JavascriptInterface
    public void confirmSoundTest() {
        sendServiceCommand(VhfMonitorService.ACTION_CONFIRM_SOUND_TEST, false);
    }

    @JavascriptInterface
    public void setCurrentEvent(int index) {
        if (index < 0 || index >= EVENT_COUNT) {
            return;
        }
        Intent command = new Intent(activity, VhfMonitorService.class)
                .setAction(VhfMonitorService.ACTION_SET_EVENT)
                .putExtra(VhfMonitorService.EXTRA_EVENT_INDEX, index);
        startService(command, false);
    }

    @JavascriptInterface
    public void requestPermissions() {
        activity.runOnUiThread(activity::requestRequiredPermissions);
    }

    @JavascriptInterface
    public void openLocationSettings() {
        activity.runOnUiThread(() -> activity.startActivity(
                new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
        ));
    }

    @JavascriptInterface
    public void openNotificationSettings() {
        activity.runOnUiThread(() -> {
            Intent intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, activity.getPackageName());
            activity.startActivity(intent);
        });
    }

    @JavascriptInterface
    public boolean saveBridgeData(String json) {
        if (json == null || json.length() > MAX_BRIDGE_JSON_LENGTH) {
            return false;
        }

        try {
            JSONObject input = new JSONObject(json);
            JSONObject clean = new JSONObject();
            Iterator<String> keys = input.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                if (!REPORT_KEYS.contains(key)) {
                    return false;
                }
                Object value = input.get(key);
                if (!(value instanceof String)) {
                    return false;
                }
                String text = (String) value;
                if (text.length() > 512) {
                    return false;
                }
                clean.put(key, text);
            }
            return bridgePreferences.edit()
                    .putString(KEY_BRIDGE_DATA, clean.toString())
                    .commit();
        } catch (JSONException error) {
            return false;
        }
    }

    @JavascriptInterface
    public String getBridgeData() {
        String value = bridgePreferences.getString(KEY_BRIDGE_DATA, "{}");
        return value == null ? "{}" : value;
    }

    private void sendServiceCommand(String action, boolean foregroundStart) {
        Intent command = new Intent(activity, VhfMonitorService.class).setAction(action);
        startService(command, foregroundStart);
    }

    private void startService(Intent intent, boolean foregroundStart) {
        activity.runOnUiThread(() -> {
            if (foregroundStart && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                activity.startForegroundService(intent);
            } else {
                activity.startService(intent);
            }
        });
    }

    private String buildBootstrapSnapshot() {
        boolean fineLocation = Build.VERSION.SDK_INT < Build.VERSION_CODES.M
                || activity.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
        NotificationManager notificationManager =
                (NotificationManager) activity.getSystemService(Context.NOTIFICATION_SERVICE);
        boolean notifications = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU
                || activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED;
        notifications = notifications
                && notificationManager != null
                && notificationManager.areNotificationsEnabled();

        LocationManager locationManager =
                (LocationManager) activity.getSystemService(Context.LOCATION_SERVICE);
        boolean gpsEnabled = locationManager != null
                && locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);

        AudioManager audioManager =
                (AudioManager) activity.getSystemService(Context.AUDIO_SERVICE);
        int alarmVolume = audioManager == null
                ? 0
                : audioManager.getStreamVolume(AudioManager.STREAM_ALARM);
        int alarmVolumeMax = audioManager == null
                ? 0
                : audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM);

        try {
            JSONObject root = new JSONObject();
            root.put("serviceRunning", false);
            root.put("armed", false);
            root.put("armRequested", false);
            root.put("canArm", false);
            root.put("goodFixCount", 0);
            root.put("gpsStatus", gpsEnabled ? "WAITING" : "DISABLED");
            root.put("stage", "MONITOR");
            root.put("statusMessage", "افتح GPS ثم اختبر الإنذار قبل بدء المراقبة");
            root.put("alarmActive", false);
            root.put("alarmKind", JSONObject.NULL);
            root.put("alarmAcknowledged", false);
            root.put("alarmSilencedUntilElapsedMs", 0);
            root.put("eventIndex", 0);
            root.put("eventCount", EVENT_COUNT);
            root.put("routeComplete", false);
            root.put("updatedAtMs", System.currentTimeMillis());

            JSONObject permissions = new JSONObject();
            permissions.put("fineLocation", fineLocation);
            permissions.put("notifications", notifications);
            root.put("permissions", permissions);

            JSONObject position = new JSONObject();
            position.put("available", false);
            position.put("latitude", JSONObject.NULL);
            position.put("longitude", JSONObject.NULL);
            position.put("latText", "—");
            position.put("lonText", "—");
            position.put("accuracyM", JSONObject.NULL);
            position.put("speedKn", JSONObject.NULL);
            position.put("ageMs", JSONObject.NULL);
            position.put("mock", false);
            position.put("timeMs", 0);
            root.put("position", position);

            JSONObject evaluation = new JSONObject();
            evaluation.put("distanceNm", JSONObject.NULL);
            evaluation.put("xteNm", JSONObject.NULL);
            evaluation.put("crossed", false);
            root.put("evaluation", evaluation);
            root.put("event", JSONObject.NULL);

            JSONObject safety = new JSONObject();
            safety.put("gpsEnabled", gpsEnabled);
            safety.put("alarmVolume", alarmVolume);
            safety.put("alarmVolumeMax", alarmVolumeMax);
            safety.put("alarmVolumeUsable", alarmVolume > 0);
            safety.put("dndAllowsAlarm", true);
            safety.put("soundTestConfirmed", false);
            safety.put("notificationChannels", notifications);
            root.put("safety", safety);
            return root.toString();
        } catch (JSONException impossible) {
            return "{}";
        }
    }
}

package com.vortexbulk.vhf;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;

/** Plays a long maritime two-tone alarm and matching vibration until explicitly stopped. */
public final class AlarmController {
    private static final String TAG = "VortexAlarm";
    private static final int SAMPLE_RATE_HZ = 44_100;
    private static final double CYCLE_SECONDS = 6.5;
    private static final long TEST_SOUND_DURATION_MS = 12_200L;
    private static final long[] VIBRATION_PATTERN_MS = {
            0L, 950L, 250L, 950L, 250L, 1_300L, 2_800L
    };

    private static volatile short[] cachedCycle;

    private final Context context;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final AudioManager audioManager;
    private final Vibrator vibrator;
    private final AudioManager.OnAudioFocusChangeListener focusListener = focusChange -> { };
    private final Runnable testStop = this::stop;

    private AudioTrack audioTrack;
    private boolean playing;

    public AlarmController(Context context) {
        this.context = context.getApplicationContext();
        audioManager = (AudioManager) this.context.getSystemService(Context.AUDIO_SERVICE);
        vibrator = (Vibrator) this.context.getSystemService(Context.VIBRATOR_SERVICE);
    }

    /** Starts the alarm.  A real alarm loops without a time limit; a test sounds for 12.2 seconds. */
    public synchronized void start(boolean testOnly) {
        stopLocked();
        requestAudioFocus();

        short[] pcm = getCyclePcm();
        try {
            AudioAttributes attributes = alarmAudioAttributes();
            AudioFormat format = new AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE_HZ)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build();
            AudioTrack track = new AudioTrack.Builder()
                    .setAudioAttributes(attributes)
                    .setAudioFormat(format)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .setBufferSizeInBytes(pcm.length * 2)
                    .build();
            if (track.getState() != AudioTrack.STATE_INITIALIZED) {
                track.release();
                throw new IllegalStateException("AudioTrack did not initialize");
            }
            int written = track.write(pcm, 0, pcm.length, AudioTrack.WRITE_BLOCKING);
            if (written < pcm.length) {
                track.release();
                throw new IllegalStateException("Incomplete alarm PCM write: " + written);
            }
            int loopResult = track.setLoopPoints(0, pcm.length, -1);
            if (loopResult != AudioTrack.SUCCESS) {
                track.release();
                throw new IllegalStateException("AudioTrack loop setup failed: " + loopResult);
            }
            track.setVolume(1.0f);
            audioTrack = track;
            track.play();
        } catch (RuntimeException error) {
            Log.e(TAG, "Unable to start alarm audio; vibration remains active", error);
            audioTrack = null;
        }

        startVibration();
        playing = true;
        if (testOnly) {
            mainHandler.postDelayed(testStop, TEST_SOUND_DURATION_MS);
        }
    }

    public synchronized void stop() {
        stopLocked();
    }

    public synchronized boolean isPlaying() {
        return playing;
    }

    public synchronized void shutdown() {
        stopLocked();
    }

    private void stopLocked() {
        mainHandler.removeCallbacks(testStop);
        AudioTrack track = audioTrack;
        audioTrack = null;
        if (track != null) {
            try {
                track.pause();
                track.flush();
                track.stop();
            } catch (IllegalStateException ignored) {
                // A partially initialized or already stopped AudioTrack is safe to release.
            }
            track.release();
        }
        if (vibrator != null) {
            vibrator.cancel();
        }
        abandonAudioFocus();
        playing = false;
    }

    private void requestAudioFocus() {
        if (audioManager == null) {
            return;
        }
        audioManager.requestAudioFocus(
                focusListener,
                AudioManager.STREAM_ALARM,
                AudioManager.AUDIOFOCUS_GAIN_TRANSIENT);
    }

    private void abandonAudioFocus() {
        if (audioManager != null) {
            audioManager.abandonAudioFocus(focusListener);
        }
    }

    private void startVibration() {
        if (vibrator == null || !vibrator.hasVibrator()) {
            return;
        }
        AudioAttributes attributes = alarmAudioAttributes();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            VibrationEffect effect = VibrationEffect.createWaveform(VIBRATION_PATTERN_MS, 0);
            vibrator.vibrate(effect, attributes);
        } else {
            // Kept for defensive compatibility even though the application minSdk is 26.
            vibrator.vibrate(VIBRATION_PATTERN_MS, 0, attributes);
        }
    }

    private static AudioAttributes alarmAudioAttributes() {
        return new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
    }

    private static short[] getCyclePcm() {
        short[] existing = cachedCycle;
        if (existing != null) {
            return existing;
        }
        synchronized (AlarmController.class) {
            if (cachedCycle == null) {
                cachedCycle = buildCyclePcm();
            }
            return cachedCycle;
        }
    }

    private static short[] buildCyclePcm() {
        int sampleCount = (int) Math.round(CYCLE_SECONDS * SAMPLE_RATE_HZ);
        double[] mixed = new double[sampleCount];
        addTone(mixed, 0.00, 560.0, 1.12);
        addTone(mixed, 1.35, 820.0, 1.12);
        addTone(mixed, 2.70, 560.0, 1.35);

        short[] pcm = new short[sampleCount];
        double peak = 0.0;
        for (double value : mixed) {
            peak = Math.max(peak, Math.abs(value));
        }
        double scale = peak > 1.0 ? 0.96 / peak : 0.96;
        for (int index = 0; index < mixed.length; index += 1) {
            double value = Math.max(-1.0, Math.min(1.0, mixed[index] * scale));
            pcm[index] = (short) Math.round(value * Short.MAX_VALUE);
        }
        return pcm;
    }

    /** Adds a swept triangle voice with a quiet second harmonic and smooth attack/release. */
    private static void addTone(
            double[] destination,
            double offsetSeconds,
            double frequencyHz,
            double durationSeconds) {
        int firstSample = (int) Math.round(offsetSeconds * SAMPLE_RATE_HZ);
        int toneSamples = (int) Math.round(durationSeconds * SAMPLE_RATE_HZ);
        double phase = 0.0;
        for (int index = 0; index < toneSamples && firstSample + index < destination.length; index += 1) {
            double time = index / (double) SAMPLE_RATE_HZ;
            double progress = time / durationSeconds;
            double sweepProgress = Math.min(1.0, progress / 0.72);
            double instantaneousFrequency = frequencyHz * (0.96 + 0.08 * sweepProgress);
            phase += 2.0 * Math.PI * instantaneousFrequency / SAMPLE_RATE_HZ;

            double attack = Math.min(1.0, time / 0.055);
            double remaining = durationSeconds - time;
            double release = Math.min(1.0, remaining / 0.20);
            double envelope = Math.max(0.0, Math.min(attack, release));
            double triangle = (2.0 / Math.PI) * Math.asin(Math.sin(phase));
            double harmonic = Math.sin(2.0 * phase);
            destination[firstSample + index] += envelope * (0.87 * triangle + 0.13 * harmonic);
        }
    }
}

package com.vortexbulk.vhf;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Stateful route/gate evaluator for the four verified eastbound VHF events.
 *
 * <p>This class deliberately contains no Android dependencies.  A fix is allowed to advance a
 * crossing counter only after it passes the age, accuracy, speed, mock-location and plausible
 * progression checks.  Near a gate it must also remain inside the 0.75 NM route corridor.</p>
 */
public final class RouteEngine {
    public static final int REQUIRED_GOOD_FIXES = 3;
    public static final double MAX_ACCURACY_M = 75.0;
    public static final long MAX_FIX_AGE_MS = 5_000L;
    public static final double MAX_SPEED_KN = 30.0;
    public static final double ROUTE_CORRIDOR_NM = 0.75;

    private static final double EARTH_RADIUS_NM = 3440.065;
    private static final double DEG = Math.PI / 180.0;

    public enum Mode {
        MERIDIAN,
        LANDMARK_ABEAM,
        SEGMENT
    }

    public static final class Event {
        public final String id;
        public final String title;
        public final String station;
        public final String channel;
        public final String action;
        public final String note;
        public final Mode mode;
        public final double cueLat;
        public final double cueLon;
        public final double gateALat;
        public final double gateALon;
        public final double gateBLat;
        public final double gateBLon;
        public final double routeStartLat;
        public final double routeStartLon;
        public final double routeEndLat;
        public final double routeEndLon;
        public final int targetSector;

        private Event(
                String id,
                String title,
                String station,
                String channel,
                String action,
                String note,
                Mode mode,
                double cueLat,
                double cueLon,
                double gateALat,
                double gateALon,
                double gateBLat,
                double gateBLon,
                double routeStartLat,
                double routeStartLon,
                double routeEndLat,
                double routeEndLon,
                int targetSector) {
            this.id = id;
            this.title = title;
            this.station = station;
            this.channel = channel;
            this.action = action;
            this.note = note;
            this.mode = mode;
            this.cueLat = cueLat;
            this.cueLon = cueLon;
            this.gateALat = gateALat;
            this.gateALon = gateALon;
            this.gateBLat = gateBLat;
            this.gateBLon = gateBLon;
            this.routeStartLat = routeStartLat;
            this.routeStartLon = routeStartLon;
            this.routeEndLat = routeEndLat;
            this.routeEndLon = routeEndLon;
            this.targetSector = targetSector;
        }
    }

    public static final class Sample {
        public final double latitude;
        public final double longitude;
        public final double accuracyM;
        public final double speedKn;
        public final long ageMs;
        public final long timeMs;
        public final boolean mock;

        public Sample(
                double latitude,
                double longitude,
                double accuracyM,
                double speedKn,
                long ageMs,
                long timeMs,
                boolean mock) {
            this.latitude = latitude;
            this.longitude = longitude;
            this.accuracyM = accuracyM;
            this.speedKn = speedKn;
            this.ageMs = ageMs;
            this.timeMs = timeMs;
            this.mock = mock;
        }

        Sample withAge(long replacementAgeMs) {
            return new Sample(
                    latitude,
                    longitude,
                    accuracyM,
                    speedKn,
                    replacementAgeMs,
                    timeMs,
                    mock);
        }
    }

    public static final class Evaluation {
        public final String stage;
        public final double distanceNm;
        public final double xteNm;
        public final boolean crossed;
        public final String message;

        private Evaluation(
                String stage,
                double distanceNm,
                double xteNm,
                boolean crossed,
                String message) {
            this.stage = stage;
            this.distanceNm = distanceNm;
            this.xteNm = xteNm;
            this.crossed = crossed;
            this.message = message;
        }
    }

    public static final List<Event> EVENTS = Collections.unmodifiableList(Arrays.asList(
            new Event(
                    "western-entry",
                    "STRAITREP WESTERN ENTRY",
                    "KLANG VTS",
                    "66",
                    "FULL STRAITREP REPORT",
                    "CROSS 100\u00b040.000\u2032E ON WP8\u2192WP9",
                    Mode.MERIDIAN,
                    2.9685667,
                    100.6666667,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    3.4663167,
                    99.9990833,
                    2.9234333,
                    100.7272,
                    1),
            new Event(
                    "coa-iyu",
                    "PULAU IYU KECHIL ABEAM",
                    "VTIS WEST",
                    "73",
                    "CONFIRMATION OF ARRIVAL \u2014 KEEP CH88 WATCH",
                    "SHIP-ROUTE CUE 01\u00b012.805\u2032N 103\u00b021.952\u2032E; CHARTED LIGHT 01\u00b011.479\u2032N 103\u00b021.140\u2032E; KEEP CH88 WATCH",
                    Mode.LANDMARK_ABEAM,
                    1.2134167,
                    103.3658667,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    1.2211667,
                    103.3532,
                    1.0393833,
                    103.65025,
                    0),
            new Event(
                    "s6-s7",
                    "SECTOR 6 \u2192 SECTOR 7",
                    "VTIS WEST",
                    "73",
                    "CH88 \u2192 CH73 ONLY ON VTS HANDOVER",
                    "OFFICIAL TG PIAI\u2013PULAU KARIMUN KECIL LINE",
                    Mode.SEGMENT,
                    1.1753,
                    103.42815,
                    1.2583333,
                    103.5125,
                    1.1533333,
                    103.4058333,
                    1.2211667,
                    103.3532,
                    1.0393833,
                    103.65025,
                    7),
            new Event(
                    "s7-s8",
                    "SECTOR 7 \u2192 SECTOR 8",
                    "VTIS CENTRAL",
                    "14",
                    "CH73 \u2192 CH14 ONLY ON VTIS HANDOVER",
                    "OFFICIAL LONGITUDE 103\u00b044.5\u2032E",
                    Mode.MERIDIAN,
                    1.1062333,
                    103.7416667,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    1.0807833,
                    103.7181833,
                    1.1340667,
                    103.76735,
                    8)
    ));

    private int eventIndex;
    private boolean seenApproachSide;
    private int postCrossingFixes;
    private Sample lastAcceptedGood;

    public RouteEngine(int initialEventIndex) {
        eventIndex = clampIndex(initialEventIndex);
    }

    public synchronized int getEventIndex() {
        return eventIndex;
    }

    public synchronized Event getCurrentEvent() {
        return eventIndex < EVENTS.size() ? EVENTS.get(eventIndex) : null;
    }

    public synchronized void setEventIndex(int replacementIndex) {
        eventIndex = clampIndex(replacementIndex);
        resetCrossingState();
    }

    public synchronized void completeCurrentEvent() {
        if (eventIndex < EVENTS.size()) {
            eventIndex += 1;
        }
        resetCrossingState();
    }

    public synchronized void resetSession() {
        lastAcceptedGood = null;
        resetCrossingState();
    }

    public synchronized void resetCrossingState() {
        seenApproachSide = false;
        postCrossingFixes = 0;
    }

    /** Returns true only when a fix can be used for arming and gate progression. */
    public synchronized boolean validateAndRecord(Sample sample) {
        if (!sampleQualifies(sample) || !plausibleProgression(sample)) {
            postCrossingFixes = 0;
            return false;
        }
        lastAcceptedGood = sample;
        return true;
    }

    public static boolean sampleQualifies(Sample sample) {
        return sample != null
                && !sample.mock
                && sample.ageMs >= 0L
                && sample.ageMs <= MAX_FIX_AGE_MS
                && Double.isFinite(sample.accuracyM)
                && sample.accuracyM > 0.0
                && sample.accuracyM <= MAX_ACCURACY_M
                && Double.isFinite(sample.speedKn)
                && sample.speedKn >= 0.0
                && sample.speedKn <= MAX_SPEED_KN
                && Double.isFinite(sample.latitude)
                && sample.latitude >= -90.0
                && sample.latitude <= 90.0
                && Double.isFinite(sample.longitude)
                && sample.longitude >= -180.0
                && sample.longitude <= 180.0;
    }

    /**
     * Evaluates the current gate.  {@code acceptedForProgression} must be the result of the same
     * fix's validation, so a GPS jump can never increment a crossing confirmation counter.
     */
    public synchronized Evaluation evaluate(Sample sample, boolean acceptedForProgression) {
        Event event = getCurrentEvent();
        if (event == null) {
            return new Evaluation(
                    "MONITOR",
                    Double.NaN,
                    Double.NaN,
                    false,
                    "ROUTE EVENTS COMPLETE");
        }

        double distanceNm = distanceToGate(sample, event);
        double xteNm = pointToSegmentNm(
                sample.latitude,
                sample.longitude,
                event.routeStartLat,
                event.routeStartLon,
                event.routeEndLat,
                event.routeEndLon);

        if (!acceptedForProgression || !sampleQualifies(sample)) {
            postCrossingFixes = 0;
            return new Evaluation(
                    "GPS_DEGRADED",
                    distanceNm,
                    xteNm,
                    false,
                    "GPS DEGRADED \u2014 CHECK ECDIS");
        }

        if (distanceNm <= 5.0 && xteNm > ROUTE_CORRIDOR_NM) {
            resetCrossingState();
            return new Evaluation(
                    "ROUTE_MISMATCH",
                    distanceNm,
                    xteNm,
                    false,
                    "OFF ROUTE CORRIDOR \u2014 AUTOMATIC CUE FROZEN");
        }

        double side = signedSide(sample, event);
        double hysteresisNm = Math.max(0.10, (2.0 * sample.accuracyM) / 1852.0);
        if (side < -hysteresisNm) {
            seenApproachSide = true;
            postCrossingFixes = 0;
        } else if (side > hysteresisNm) {
            if (!seenApproachSide) {
                return new Evaluation(
                        "AHEAD_CONFIRM",
                        distanceNm,
                        xteNm,
                        false,
                        "POSITION AHEAD \u2014 CONFIRM CURRENT STAGE WITH ECDIS/VTS");
            }
            postCrossingFixes += 1;
        } else {
            postCrossingFixes = 0;
        }

        if (seenApproachSide && postCrossingFixes >= 3) {
            return new Evaluation(
                    "CROSSED_WAITING_ACK",
                    distanceNm,
                    xteNm,
                    true,
                    "GATE CROSSED \u2014 REPORT/HANDOVER CONFIRMATION REQUIRED");
        }
        if (distanceNm <= 0.5) {
            return new Evaluation(
                    "ACTION_DUE",
                    distanceNm,
                    xteNm,
                    false,
                    "AT GATE \u2014 VERIFY ACTION");
        }
        if (distanceNm <= 2.0) {
            return new Evaluation(
                    "STANDBY",
                    distanceNm,
                    xteNm,
                    false,
                    "STANDBY \u2014 2 NM");
        }
        if (distanceNm <= 5.0) {
            return new Evaluation(
                    "PREPARE",
                    distanceNm,
                    xteNm,
                    false,
                    "PREPARE \u2014 5 NM");
        }
        return new Evaluation("MONITOR", distanceNm, xteNm, false, "MONITOR");
    }

    private boolean plausibleProgression(Sample sample) {
        Sample previous = lastAcceptedGood;
        if (previous == null) {
            return true;
        }
        double elapsedHours = (sample.timeMs - previous.timeMs) / 3_600_000.0;
        if (elapsedHours <= 0.0) {
            return false;
        }
        double traveledNm = haversineNm(
                previous.latitude,
                previous.longitude,
                sample.latitude,
                sample.longitude);
        double allowanceNm = (previous.accuracyM + sample.accuracyM) / 1852.0;
        return traveledNm <= MAX_SPEED_KN * elapsedHours + allowanceNm;
    }

    private static int clampIndex(int index) {
        return Math.max(0, Math.min(EVENTS.size(), index));
    }

    private static double haversineNm(
            double latitude1,
            double longitude1,
            double latitude2,
            double longitude2) {
        double dLat = (latitude2 - latitude1) * DEG;
        double dLon = (longitude2 - longitude1) * DEG;
        double a = Math.sin(dLat / 2.0) * Math.sin(dLat / 2.0)
                + Math.cos(latitude1 * DEG)
                * Math.cos(latitude2 * DEG)
                * Math.sin(dLon / 2.0)
                * Math.sin(dLon / 2.0);
        return EARTH_RADIUS_NM * 2.0
                * Math.atan2(Math.sqrt(a), Math.sqrt(Math.max(0.0, 1.0 - a)));
    }

    private static double meridianDistanceNm(double latitude, double longitude, double gateLon) {
        return Math.abs(longitude - gateLon) * 60.0 * Math.cos(latitude * DEG);
    }

    private static double pointToSegmentNm(
            double latitude,
            double longitude,
            double aLat,
            double aLon,
            double bLat,
            double bLon) {
        double refLat = ((latitude + aLat + bLat) / 3.0) * DEG;
        double px = longitude * 60.0 * Math.cos(refLat);
        double py = latitude * 60.0;
        double ax = aLon * 60.0 * Math.cos(refLat);
        double ay = aLat * 60.0;
        double bx = bLon * 60.0 * Math.cos(refLat);
        double by = bLat * 60.0;
        double dx = bx - ax;
        double dy = by - ay;
        double lengthSquared = dx * dx + dy * dy;
        double projection = lengthSquared == 0.0
                ? 0.0
                : ((px - ax) * dx + (py - ay) * dy) / lengthSquared;
        double t = Math.max(0.0, Math.min(1.0, projection));
        return Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
    }

    private static double signedLineDistanceNm(
            double latitude,
            double longitude,
            double aLat,
            double aLon,
            double bLat,
            double bLon) {
        double refLat = ((latitude + aLat + bLat) / 3.0) * DEG;
        double px = (longitude - aLon) * 60.0 * Math.cos(refLat);
        double py = (latitude - aLat) * 60.0;
        double dx = (bLon - aLon) * 60.0 * Math.cos(refLat);
        double dy = (bLat - aLat) * 60.0;
        double length = Math.hypot(dx, dy);
        return length == 0.0 ? 0.0 : (dx * py - dy * px) / length;
    }

    private static double signedAlongTrackNm(double latitude, double longitude, Event event) {
        double refLat = event.cueLat * DEG;
        double dx = (event.routeEndLon - event.routeStartLon) * 60.0 * Math.cos(refLat);
        double dy = (event.routeEndLat - event.routeStartLat) * 60.0;
        double length = Math.hypot(dx, dy);
        if (length == 0.0) {
            return 0.0;
        }
        double px = (longitude - event.cueLon) * 60.0 * Math.cos(refLat);
        double py = (latitude - event.cueLat) * 60.0;
        return (px * dx + py * dy) / length;
    }

    private static double distanceToGate(Sample sample, Event event) {
        if (event.mode == Mode.MERIDIAN) {
            return meridianDistanceNm(sample.latitude, sample.longitude, event.cueLon);
        }
        if (event.mode == Mode.SEGMENT) {
            return pointToSegmentNm(
                    sample.latitude,
                    sample.longitude,
                    event.gateALat,
                    event.gateALon,
                    event.gateBLat,
                    event.gateBLon);
        }
        return Math.abs(signedAlongTrackNm(sample.latitude, sample.longitude, event));
    }

    private static double signedSide(Sample sample, Event event) {
        if (event.mode == Mode.MERIDIAN) {
            return (sample.longitude - event.cueLon)
                    * 60.0
                    * Math.cos(sample.latitude * DEG);
        }
        if (event.mode == Mode.SEGMENT) {
            return signedLineDistanceNm(
                    sample.latitude,
                    sample.longitude,
                    event.gateALat,
                    event.gateALon,
                    event.gateBLat,
                    event.gateBLon);
        }
        return signedAlongTrackNm(sample.latitude, sample.longitude, event);
    }
}

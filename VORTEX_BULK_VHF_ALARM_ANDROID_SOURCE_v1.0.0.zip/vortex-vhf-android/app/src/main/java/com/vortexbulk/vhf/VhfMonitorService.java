package com.vortexbulk.vhf;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Foreground GPS service used by the local WebView bridge.
 *
 * <p>It uses GPS_PROVIDER only, validates three consecutive fixes before arming, persists a JSON
 * snapshot for WebView polling, and owns the native alarm so it continues with the screen locked.
 * ACK silences the current warning; only COMPLETE advances to the next route event.</p>
 */
public final class VhfMonitorService extends Service implements LocationListener {
    public static final String PREFS_NAME = "vortex_vhf_native_state_v1";
    public static final String KEY_SNAPSHOT_JSON = "snapshot_json";

    public static final String ACTION_START = "com.vortexbulk.vhf.action.START";
    public static final String ACTION_STOP = "com.vortexbulk.vhf.action.STOP";
    public static final String ACTION_ACK = "com.vortexbulk.vhf.action.ACK";
    public static final String ACTION_COMPLETE = "com.vortexbulk.vhf.action.COMPLETE";
    public static final String ACTION_SET_EVENT = "com.vortexbulk.vhf.action.SET_EVENT";
    public static final String ACTION_TEST = "com.vortexbulk.vhf.action.TEST";
    public static final String ACTION_CONFIRM_SOUND_TEST =
            "com.vortexbulk.vhf.action.CONFIRM_SOUND_TEST";

    // Public aliases used by VhfBridge.  Keeping one canonical action string prevents ambiguity.
    public static final String ACTION_ARM = ACTION_START;
    public static final String ACTION_DISARM = ACTION_STOP;
    public static final String ACTION_ACKNOWLEDGE = ACTION_ACK;
    public static final String ACTION_TEST_ALARM = ACTION_TEST;

    public static final String EXTRA_EVENT_INDEX = "event_index";

    private static final String KEY_EVENT_INDEX = "event_index";
    public static final String KEY_MONITORING_REQUESTED = "monitoring_requested";
    private static final String KEY_SOUND_TEST_CONFIRMED = "sound_test_confirmed";
    private static final String KEY_ACKNOWLEDGED_KEYS = "acknowledged_alarm_keys";

    private static final String CHANNEL_MONITORING = "vhf_monitoring_v1";
    private static final String CHANNEL_ALARM = "vhf_alarm_v1";
    private static final int FOREGROUND_NOTIFICATION_ID = 7301;
    private static final int TEST_NOTIFICATION_ID = 7302;
    private static final long LOCATION_INTERVAL_MS = 1_000L;
    private static final long GPS_WARNING_MS = 10_000L;
    private static final long GPS_STALE_MS = 30_000L;
    private static final long WATCHDOG_INTERVAL_MS = 5_000L;
    private static final long SOUND_TEST_WINDOW_MS = 120_000L;
    private static final double METRES_PER_SECOND_TO_KNOTS = 1.9438445;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Set<String> acknowledgedAlarmKeys = new HashSet<>();
    private final Runnable watchdog = new Runnable() {
        @Override
        public void run() {
            watchdogTick();
            if (monitoringRequested) {
                mainHandler.postDelayed(this, WATCHDOG_INTERVAL_MS);
            }
        }
    };
    private final Runnable soundTestExpiry = new Runnable() {
        @Override
        public void run() {
            if (!testOnly) {
                return;
            }
            alarmController.stop();
            testOnly = false;
            serviceRunning = false;
            alarmActive = false;
            alarmKind = "";
            alarmAcknowledged = false;
            currentAlarmKey = "";
            statusMessage = "SOUND TEST EXPIRED \u2014 RUN IT AGAIN";
            publishSnapshot();
            cancelTestNotification();
            stopSelf();
        }
    };

    private SharedPreferences preferences;
    private LocationManager locationManager;
    private NotificationManager notificationManager;
    private AudioManager audioManager;
    private AlarmController alarmController;
    private RouteEngine routeEngine;
    private PowerManager.WakeLock wakeLock;

    private boolean serviceRunning;
    private boolean monitoringRequested;
    private boolean armed;
    private boolean testOnly;
    private boolean soundTestConfirmed;
    private int goodFixCount;
    private long monitoringStartedElapsedMs;
    private long lastGoodElapsedMs;
    private long soundTestStartedElapsedMs;

    private String gpsStatus = "DISARMED";
    private String stage = "DISARMED";
    private String statusMessage = "READY \u2014 TEST SOUND, THEN ARM GPS MONITORING";
    private boolean alarmActive;
    private String alarmKind = "";
    private boolean alarmAcknowledged;
    private long alarmSilencedUntilElapsedMs;
    private String currentAlarmKey = "";

    private RouteEngine.Sample lastSample;
    private boolean lastSampleAccepted;
    private RouteEngine.Evaluation lastEvaluation;

    @Override
    public void onCreate() {
        super.onCreate();
        preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        alarmController = new AlarmController(this);
        routeEngine = new RouteEngine(preferences.getInt(KEY_EVENT_INDEX, 0));
        soundTestConfirmed = preferences.getBoolean(KEY_SOUND_TEST_CONFIRMED, false);
        Set<String> savedKeys = preferences.getStringSet(KEY_ACKNOWLEDGED_KEYS, null);
        if (savedKeys != null) {
            acknowledgedAlarmKeys.addAll(savedKeys);
        }
        createNotificationChannels();
        publishSnapshot();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        boolean commandNeedsLiveMonitoring = ACTION_ACK.equals(action)
                || ACTION_COMPLETE.equals(action)
                || ACTION_SET_EVENT.equals(action);
        if (commandNeedsLiveMonitoring
                && !monitoringRequested
                && preferences.getBoolean(KEY_MONITORING_REQUESTED, false)) {
            // A notification/service command may recreate the process.  Restore the foreground
            // GPS session first so ACK/COMPLETE can never leave a persisted voyage silently dead.
            resumeMonitoringAfterRestart();
        }
        if (ACTION_START.equals(action)) {
            startMonitoring();
        } else if (ACTION_STOP.equals(action)) {
            stopMonitoring();
        } else if (ACTION_ACK.equals(action)) {
            acknowledgeAlarm();
        } else if (ACTION_COMPLETE.equals(action)) {
            completeCurrentEvent();
        } else if (ACTION_SET_EVENT.equals(action)) {
            int replacement = intent.getIntExtra(EXTRA_EVENT_INDEX, routeEngine.getEventIndex());
            setCurrentEvent(replacement);
        } else if (ACTION_TEST.equals(action)) {
            startSoundTest();
        } else if (ACTION_CONFIRM_SOUND_TEST.equals(action)) {
            confirmSoundTest();
        } else if (intent == null && preferences.getBoolean(KEY_MONITORING_REQUESTED, false)) {
            // START_STICKY process recreation while an officer had monitoring armed.
            soundTestConfirmed = preferences.getBoolean(KEY_SOUND_TEST_CONFIRMED, false);
            resumeMonitoringAfterRestart();
        } else {
            publishSnapshot();
        }
        return monitoringRequested ? START_STICKY : START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        mainHandler.removeCallbacks(watchdog);
        mainHandler.removeCallbacks(soundTestExpiry);
        removeLocationUpdates();
        if (alarmController != null) {
            alarmController.shutdown();
        }
        releaseWakeLock();
        super.onDestroy();
    }

    private void startMonitoring() {
        if (monitoringRequested) {
            updateForegroundNotification();
            publishSnapshot();
            return;
        }

        // ACTION_ARM is launched as a foreground service.  Satisfy the five-second requirement
        // immediately, then report any safety gate that prevents arming.
        serviceRunning = true;
        if (!startForegroundSafely()) {
            return;
        }

        if (!soundTestConfirmed) {
            serviceRunning = false;
            gpsStatus = "DISARMED";
            stage = "DISARMED";
            statusMessage = "ARMING BLOCKED \u2014 RUN AND CONFIRM SOUND TEST";
            publishSnapshot();
            stopForegroundAndSelf();
            return;
        }
        if (!hasFineLocationPermission()) {
            serviceRunning = false;
            gpsStatus = "DENIED";
            stage = "GPS_DEGRADED";
            statusMessage = "PRECISE LOCATION PERMISSION REQUIRED";
            publishSnapshot();
            stopForegroundAndSelf();
            return;
        }
        if (!isGpsEnabled()) {
            serviceRunning = false;
            gpsStatus = "DISABLED";
            stage = "GPS_DEGRADED";
            statusMessage = "GPS PROVIDER DISABLED \u2014 ENABLE DEVICE LOCATION";
            publishSnapshot();
            stopForegroundAndSelf();
            return;
        }
        if (!notificationChannelsUsable()) {
            serviceRunning = false;
            gpsStatus = "DISARMED";
            stage = "DISARMED";
            statusMessage = "ARMING BLOCKED \u2014 ENABLE APP AND ALARM NOTIFICATIONS";
            publishSnapshot();
            stopForegroundAndSelf();
            return;
        }
        if (!alarmVolumeUsable()) {
            serviceRunning = false;
            gpsStatus = "DISARMED";
            stage = "DISARMED";
            statusMessage = "ARMING BLOCKED \u2014 ALARM VOLUME IS ZERO";
            publishSnapshot();
            stopForegroundAndSelf();
            return;
        }
        if (!dndAllowsAlarm()) {
            serviceRunning = false;
            gpsStatus = "DISARMED";
            stage = "DISARMED";
            statusMessage = "ARMING BLOCKED \u2014 DO NOT DISTURB MAY SILENCE ALARMS";
            publishSnapshot();
            stopForegroundAndSelf();
            return;
        }

        monitoringRequested = true;
        armed = false;
        testOnly = false;
        goodFixCount = 0;
        monitoringStartedElapsedMs = SystemClock.elapsedRealtime();
        lastGoodElapsedMs = 0L;
        lastSample = null;
        lastSampleAccepted = false;
        lastEvaluation = null;
        gpsStatus = "ACQUIRING";
        stage = "ACQUIRING";
        statusMessage = "ACQUIRING 0/3 GOOD GPS FIXES";
        clearAlarmState(true);
        routeEngine.resetSession();
        preferences.edit()
                .putBoolean(KEY_MONITORING_REQUESTED, true)
                .putStringSet(KEY_ACKNOWLEDGED_KEYS, new HashSet<>())
                .apply();
        acquireWakeLock();
        requestLocationUpdates();
        mainHandler.removeCallbacks(watchdog);
        mainHandler.postDelayed(watchdog, WATCHDOG_INTERVAL_MS);
        updateForegroundNotification();
        publishSnapshot();
    }

    private void resumeMonitoringAfterRestart() {
        serviceRunning = true;
        monitoringRequested = true;
        armed = false;
        goodFixCount = 0;
        monitoringStartedElapsedMs = SystemClock.elapsedRealtime();
        lastGoodElapsedMs = 0L;
        gpsStatus = "ACQUIRING";
        stage = "ACQUIRING";
        statusMessage = "SERVICE RESTORED \u2014 ACQUIRING 0/3 GOOD GPS FIXES";
        clearAlarmState(false);
        routeEngine.resetSession();
        if (!startForegroundSafely()) {
            return;
        }
        if (!canArm()) {
            serviceRunning = false;
            monitoringRequested = false;
            armed = false;
            gpsStatus = "DISARMED";
            stage = "DISARMED";
            statusMessage = "MONITORING NOT RESTORED \u2014 REOPEN APP AND CHECK SAFETY SETTINGS";
            preferences.edit().putBoolean(KEY_MONITORING_REQUESTED, false).apply();
            publishSnapshot();
            stopForegroundAndSelf();
            return;
        }
        acquireWakeLock();
        requestLocationUpdates();
        mainHandler.removeCallbacks(watchdog);
        mainHandler.postDelayed(watchdog, WATCHDOG_INTERVAL_MS);
        publishSnapshot();
    }

    private void stopMonitoring() {
        monitoringRequested = false;
        serviceRunning = false;
        armed = false;
        testOnly = false;
        soundTestConfirmed = false;
        goodFixCount = 0;
        gpsStatus = "DISARMED";
        stage = "DISARMED";
        statusMessage = "DISARMED \u2014 NATIVE GPS MONITORING STOPPED";
        lastSample = null;
        lastSampleAccepted = false;
        lastEvaluation = null;
        soundTestStartedElapsedMs = 0L;
        mainHandler.removeCallbacks(watchdog);
        mainHandler.removeCallbacks(soundTestExpiry);
        removeLocationUpdates();
        routeEngine.resetSession();
        clearAlarmState(true);
        releaseWakeLock();
        preferences.edit()
                .putBoolean(KEY_MONITORING_REQUESTED, false)
                .putBoolean(KEY_SOUND_TEST_CONFIRMED, false)
                .putStringSet(KEY_ACKNOWLEDGED_KEYS, new HashSet<>())
                .apply();
        publishSnapshot();
        cancelTestNotification();
        stopForegroundAndSelf();
    }

    private void requestLocationUpdates() {
        if (locationManager == null || !hasFineLocationPermission()) {
            return;
        }
        try {
            locationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    LOCATION_INTERVAL_MS,
                    0.0f,
                    this,
                    Looper.getMainLooper());
        } catch (SecurityException error) {
            gpsStatus = "DENIED";
            stage = "GPS_DEGRADED";
            statusMessage = "LOCATION PERMISSION REVOKED \u2014 CHECK ECDIS";
            armed = false;
            goodFixCount = 0;
            routeEngine.resetSession();
            publishSnapshot();
        } catch (IllegalArgumentException error) {
            gpsStatus = "UNAVAILABLE";
            stage = "GPS_DEGRADED";
            statusMessage = "GPS PROVIDER UNAVAILABLE \u2014 CHECK ECDIS";
            publishSnapshot();
        }
    }

    private void removeLocationUpdates() {
        if (locationManager == null) {
            return;
        }
        try {
            locationManager.removeUpdates(this);
        } catch (SecurityException ignored) {
            // Permission may have been removed while monitoring.
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        if (!monitoringRequested || location == null) {
            return;
        }

        long nowElapsedNanos = SystemClock.elapsedRealtimeNanos();
        long fixElapsedNanos = location.getElapsedRealtimeNanos();
        long ageMs;
        if (fixElapsedNanos > 0L && nowElapsedNanos >= fixElapsedNanos) {
            ageMs = (nowElapsedNanos - fixElapsedNanos) / 1_000_000L;
        } else {
            ageMs = Math.max(0L, System.currentTimeMillis() - location.getTime());
        }
        double speedKn = location.hasSpeed()
                ? location.getSpeed() * METRES_PER_SECOND_TO_KNOTS
                : 0.0;
        boolean mock = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                ? location.isMock()
                : location.isFromMockProvider();
        boolean fromGpsProvider = LocationManager.GPS_PROVIDER.equals(location.getProvider());

        RouteEngine.Sample sample = new RouteEngine.Sample(
                location.getLatitude(),
                location.getLongitude(),
                location.hasAccuracy() ? location.getAccuracy() : Double.NaN,
                speedKn,
                ageMs,
                location.getTime() > 0L ? location.getTime() : System.currentTimeMillis(),
                mock || !fromGpsProvider);
        lastSample = sample;

        boolean good = routeEngine.validateAndRecord(sample);
        lastSampleAccepted = good;
        if (good) {
            lastGoodElapsedMs = SystemClock.elapsedRealtime();
            goodFixCount = Math.min(RouteEngine.REQUIRED_GOOD_FIXES, goodFixCount + 1);
            gpsStatus = goodFixCount < RouteEngine.REQUIRED_GOOD_FIXES ? "ACQUIRING" : "GOOD";
        } else {
            goodFixCount = 0;
            armed = false;
            gpsStatus = mock ? "MOCK_REJECTED" : "DEGRADED";
            routeEngine.resetSession();
        }

        if (!armed) {
            if (goodFixCount >= RouteEngine.REQUIRED_GOOD_FIXES) {
                armed = true;
                statusMessage = "ARMED \u2014 NATIVE GPS MONITORING ACTIVE";
            } else if (!good) {
                stage = "GPS_DEGRADED";
                statusMessage = "GPS FIX REJECTED \u2014 ACQUIRE 3 NEW GOOD FIXES; CHECK ECDIS";
            } else {
                stage = "ACQUIRING";
                statusMessage = "ACQUIRING " + goodFixCount + "/3 GOOD GPS FIXES";
            }
        }

        if (armed) {
            lastEvaluation = routeEngine.evaluate(sample, good);
            handleEvaluation(lastEvaluation);
        }
        updateForegroundNotification();
        publishSnapshot();
    }

    @Override
    public void onProviderDisabled(String provider) {
        if (!LocationManager.GPS_PROVIDER.equals(provider) || !monitoringRequested) {
            return;
        }
        armed = false;
        goodFixCount = 0;
        gpsStatus = "DISABLED";
        stage = "GPS_DEGRADED";
        statusMessage = "GPS DISABLED \u2014 AUTOMATIC CUES FROZEN; CHECK ECDIS";
        routeEngine.resetSession();
        startAlarm(
                "SYSTEM:GPS_DISABLED",
                "GPS_DISABLED",
                "GPS LOST / DISABLED",
                statusMessage);
        updateForegroundNotification();
        publishSnapshot();
    }

    @Override
    public void onProviderEnabled(String provider) {
        if (!LocationManager.GPS_PROVIDER.equals(provider) || !monitoringRequested) {
            return;
        }
        gpsStatus = "ACQUIRING";
        stage = "ACQUIRING";
        statusMessage = "GPS ENABLED \u2014 ACQUIRING 0/3 GOOD FIXES";
        armed = false;
        goodFixCount = 0;
        routeEngine.resetSession();
        publishSnapshot();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onStatusChanged(String provider, int status, Bundle extras) {
        // Provider enabled/disabled callbacks and the stale watchdog are authoritative.
    }

    private void watchdogTick() {
        if (!monitoringRequested) {
            return;
        }
        long now = SystemClock.elapsedRealtime();
        long reference = lastGoodElapsedMs > 0L ? lastGoodElapsedMs : monitoringStartedElapsedMs;
        long goodAgeMs = Math.max(0L, now - reference);
        if (goodAgeMs > GPS_STALE_MS) {
            armed = false;
            goodFixCount = 0;
            gpsStatus = "STALE";
            stage = "GPS_DEGRADED";
            statusMessage = "NO USABLE GPS FIX FOR 30 SECONDS \u2014 CHECK ECDIS";
            routeEngine.resetSession();
            startAlarm(
                    "SYSTEM:GPS_STALE",
                    "GPS_STALE",
                    "GPS LOST / STALE",
                    statusMessage);
        } else if (goodAgeMs > GPS_WARNING_MS && armed) {
            armed = false;
            goodFixCount = 0;
            gpsStatus = "DEGRADED";
            stage = "GPS_DEGRADED";
            statusMessage = "GPS DEGRADED \u2014 AUTOMATIC GATE CUES FROZEN";
            routeEngine.resetSession();
        }
        updateForegroundNotification();
        publishSnapshot();
    }

    private void handleEvaluation(RouteEngine.Evaluation evaluation) {
        stage = evaluation.stage;
        statusMessage = evaluation.message;
        RouteEngine.Event event = routeEngine.getCurrentEvent();
        if (event == null) {
            return;
        }
        if ("PREPARE".equals(evaluation.stage)
                || "STANDBY".equals(evaluation.stage)
                || "ACTION_DUE".equals(evaluation.stage)
                || "CROSSED_WAITING_ACK".equals(evaluation.stage)
                || "AHEAD_CONFIRM".equals(evaluation.stage)) {
            String key = "EVENT:" + event.id + ":" + evaluation.stage;
            startAlarm(
                    key,
                    evaluation.stage,
                    event.station + " \u2014 CH " + event.channel,
                    event.action + "\n" + evaluation.message);
        } else if ("ROUTE_MISMATCH".equals(evaluation.stage)) {
            startAlarm(
                    "SYSTEM:ROUTE_MISMATCH",
                    "ROUTE_MISMATCH",
                    "ROUTE MISMATCH",
                    evaluation.message);
        }
    }

    private void startAlarm(String key, String kind, String title, String detail) {
        if (acknowledgedAlarmKeys.contains(key)) {
            return;
        }
        if (key.equals(currentAlarmKey)) {
            if (alarmActive) {
                return;
            }
            if (alarmAcknowledged) {
                return;
            }
        }

        alarmController.stop();
        currentAlarmKey = key;
        alarmKind = kind;
        alarmActive = true;
        alarmAcknowledged = false;
        alarmSilencedUntilElapsedMs = 0L;
        alarmController.start(false);
        statusMessage = detail;
        updateForegroundNotification(title, detail, true);
        publishSnapshot();
    }

    private void acknowledgeAlarm() {
        if (currentAlarmKey.isEmpty()) {
            publishSnapshot();
            return;
        }
        alarmController.stop();
        alarmActive = false;
        alarmAcknowledged = true;
        alarmSilencedUntilElapsedMs = 0L;
        acknowledgedAlarmKeys.add(currentAlarmKey);
        preferences.edit()
                .putStringSet(KEY_ACKNOWLEDGED_KEYS, new HashSet<>(acknowledgedAlarmKeys))
                .apply();
        statusMessage = alarmKind + " ACKNOWLEDGED \u2014 EVENT NOT COMPLETED";
        updateForegroundNotification();
        publishSnapshot();
    }

    private void completeCurrentEvent() {
        if (routeEngine.getCurrentEvent() == null) {
            publishSnapshot();
            return;
        }
        alarmController.stop();
        routeEngine.completeCurrentEvent();
        persistEventIndex();
        clearAlarmState(true);
        lastEvaluation = null;
        statusMessage = routeEngine.getCurrentEvent() == null
                ? "ROUTE EVENTS COMPLETE \u2014 CONTINUE ECDIS/VTS WATCH"
                : "EVENT COMPLETED BY OFFICER \u2014 MONITORING NEXT EVENT";
        if (armed && lastSample != null) {
            lastEvaluation = routeEngine.evaluate(lastSample, lastSampleAccepted);
            handleEvaluation(lastEvaluation);
        } else if (routeEngine.getCurrentEvent() == null) {
            stage = "MONITOR";
        }
        updateForegroundNotification();
        publishSnapshot();
    }

    private void setCurrentEvent(int replacementIndex) {
        alarmController.stop();
        routeEngine.setEventIndex(replacementIndex);
        persistEventIndex();
        clearAlarmState(true);
        lastEvaluation = null;
        stage = "MONITOR";
        statusMessage = routeEngine.getCurrentEvent() == null
                ? "ROUTE EVENTS COMPLETE \u2014 CONTINUE ECDIS/VTS WATCH"
                : "EVENT SELECTED BY OFFICER \u2014 VERIFY AGAINST ECDIS/VTS";
        if (armed && lastSample != null) {
            lastEvaluation = routeEngine.evaluate(lastSample, lastSampleAccepted);
            handleEvaluation(lastEvaluation);
        }
        updateForegroundNotification();
        publishSnapshot();
    }

    private void startSoundTest() {
        if (monitoringRequested) {
            statusMessage = "DISARM BEFORE RUNNING THE SOUND TEST";
            publishSnapshot();
            return;
        }
        mainHandler.removeCallbacks(soundTestExpiry);
        alarmController.stop();
        serviceRunning = true;
        testOnly = true;
        soundTestConfirmed = false;
        soundTestStartedElapsedMs = SystemClock.elapsedRealtime();
        currentAlarmKey = "TEST";
        alarmKind = "TEST";
        alarmActive = true;
        alarmAcknowledged = false;
        alarmSilencedUntilElapsedMs = 0L;
        statusMessage =
                "LONG TWO-TONE ALARM TEST \u2014 CONFIRM THAT YOU HEARD THE FULL SOUND CYCLE";
        preferences.edit().putBoolean(KEY_SOUND_TEST_CONFIRMED, false).apply();
        alarmController.start(true);
        mainHandler.postDelayed(soundTestExpiry, SOUND_TEST_WINDOW_MS);
        showTestNotification();
        publishSnapshot();
    }

    private void confirmSoundTest() {
        long elapsed = SystemClock.elapsedRealtime() - soundTestStartedElapsedMs;
        boolean recent = soundTestStartedElapsedMs > 0L
                && elapsed >= 0L
                && elapsed <= SOUND_TEST_WINDOW_MS;
        if (!testOnly || !recent) {
            statusMessage = "SOUND TEST CONFIRMATION BLOCKED \u2014 TEST AGAIN";
            publishSnapshot();
            return;
        }
        mainHandler.removeCallbacks(soundTestExpiry);
        alarmController.stop();
        soundTestConfirmed = true;
        testOnly = false;
        serviceRunning = false;
        currentAlarmKey = "";
        alarmKind = "";
        alarmActive = false;
        alarmAcknowledged = false;
        alarmSilencedUntilElapsedMs = 0L;
        statusMessage = "SOUND AND VIBRATION CONFIRMED BY OFFICER";
        preferences.edit().putBoolean(KEY_SOUND_TEST_CONFIRMED, true).apply();
        cancelTestNotification();
        publishSnapshot();
        stopSelf();
    }

    private void clearAlarmState(boolean clearAcknowledgedKeys) {
        alarmController.stop();
        currentAlarmKey = "";
        alarmKind = "";
        alarmActive = false;
        alarmAcknowledged = false;
        alarmSilencedUntilElapsedMs = 0L;
        if (clearAcknowledgedKeys) {
            acknowledgedAlarmKeys.clear();
            preferences.edit()
                    .putStringSet(KEY_ACKNOWLEDGED_KEYS, new HashSet<>())
                    .apply();
        }
        routeEngine.resetCrossingState();
    }

    private void persistEventIndex() {
        preferences.edit().putInt(KEY_EVENT_INDEX, routeEngine.getEventIndex()).apply();
    }

    private void acquireWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) {
            return;
        }
        PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (powerManager == null) {
            return;
        }
        wakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                getPackageName() + ":VhfMonitor");
        wakeLock.setReferenceCounted(false);
        wakeLock.acquire();
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
        wakeLock = null;
    }

    private void createNotificationChannels() {
        if (notificationManager == null) {
            return;
        }
        NotificationChannel monitoring = new NotificationChannel(
                CHANNEL_MONITORING,
                "VHF GPS monitoring",
                NotificationManager.IMPORTANCE_LOW);
        monitoring.setDescription("Persistent status while VHF route monitoring is armed");
        monitoring.setSound(null, null);
        monitoring.enableVibration(false);

        NotificationChannel alarm = new NotificationChannel(
                CHANNEL_ALARM,
                "VHF action alarms",
                NotificationManager.IMPORTANCE_HIGH);
        alarm.setDescription("Urgent VHF report and handover alarms");
        // Native AudioTrack/Vibrator provide the repeating pattern; channel sound must not add a
        // second short beep on top of it.
        alarm.setSound(null, null);
        alarm.enableVibration(false);
        alarm.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);

        notificationManager.createNotificationChannel(monitoring);
        notificationManager.createNotificationChannel(alarm);
    }

    private boolean startForegroundSafely() {
        Notification notification = buildNotification(false, null, null);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                        FOREGROUND_NOTIFICATION_ID,
                        notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
            } else {
                startForeground(FOREGROUND_NOTIFICATION_ID, notification);
            }
            return true;
        } catch (RuntimeException error) {
            serviceRunning = false;
            monitoringRequested = false;
            armed = false;
            gpsStatus = "DENIED";
            stage = "GPS_DEGRADED";
            statusMessage = "FOREGROUND LOCATION SERVICE BLOCKED \u2014 CHECK PERMISSIONS";
            preferences.edit().putBoolean(KEY_MONITORING_REQUESTED, false).apply();
            publishSnapshot();
            stopSelf();
            return false;
        }
    }

    private void updateForegroundNotification() {
        updateForegroundNotification(null, null, alarmActive);
    }

    private void updateForegroundNotification(String title, String detail, boolean urgent) {
        if (!monitoringRequested || notificationManager == null) {
            return;
        }
        Notification notification = buildNotification(urgent, title, detail);
        notificationManager.notify(FOREGROUND_NOTIFICATION_ID, notification);
    }

    private Notification buildNotification(boolean urgent, String overrideTitle, String overrideText) {
        RouteEngine.Event event = routeEngine == null ? null : routeEngine.getCurrentEvent();
        String title = overrideTitle;
        if (title == null || title.isEmpty()) {
            title = event == null
                    ? "VORTEX BULK \u2014 ROUTE EVENTS COMPLETE"
                    : event.station + " \u00b7 CH " + event.channel;
        }
        String text = overrideText;
        if (text == null || text.isEmpty()) {
            text = statusMessage;
        }
        String channel = urgent ? CHANNEL_ALARM : CHANNEL_MONITORING;
        Intent launchIntent = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (launchIntent == null) {
            launchIntent = new Intent();
            launchIntent.setPackage(getPackageName());
        }
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(
                this,
                7300,
                launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = new Notification.Builder(this, channel)
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(contentIntent)
                .setOngoing(monitoringRequested)
                .setOnlyAlertOnce(!urgent)
                .setCategory(urgent ? Notification.CATEGORY_ALARM : Notification.CATEGORY_SERVICE)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setPriority(urgent ? Notification.PRIORITY_MAX : Notification.PRIORITY_LOW);

        if (alarmActive && !"TEST".equals(currentAlarmKey)) {
            Intent acknowledge = new Intent(this, VhfMonitorService.class)
                    .setAction(ACTION_ACK);
            PendingIntent acknowledgeIntent = PendingIntent.getService(
                    this,
                    7303,
                    acknowledge,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            builder.addAction(
                    new Notification.Action.Builder(
                            android.R.drawable.ic_media_pause,
                            "ACK \u2014 SILENCE",
                            acknowledgeIntent)
                            .build());
        }
        return builder.build();
    }

    private void showTestNotification() {
        if (notificationManager == null || !notificationsAllowed()) {
            return;
        }
        Notification notification = buildNotification(
                true,
                "VHF ALARM TEST",
                "Confirm the long sound and vibration in the app.");
        notificationManager.notify(TEST_NOTIFICATION_ID, notification);
    }

    private void cancelTestNotification() {
        if (notificationManager != null) {
            notificationManager.cancel(TEST_NOTIFICATION_ID);
        }
    }

    private void stopForegroundAndSelf() {
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private boolean hasFineLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    private boolean isGpsEnabled() {
        if (locationManager == null) {
            return false;
        }
        try {
            return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        } catch (RuntimeException ignored) {
            return false;
        }
    }

    private boolean notificationsAllowed() {
        if (notificationManager == null || !notificationManager.areNotificationsEnabled()) {
            return false;
        }
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU
                || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private boolean notificationChannelsUsable() {
        if (!notificationsAllowed() || notificationManager == null) {
            return false;
        }
        NotificationChannel monitor = notificationManager.getNotificationChannel(CHANNEL_MONITORING);
        NotificationChannel alarm = notificationManager.getNotificationChannel(CHANNEL_ALARM);
        return monitor != null
                && alarm != null
                && monitor.getImportance() != NotificationManager.IMPORTANCE_NONE
                && alarm.getImportance() != NotificationManager.IMPORTANCE_NONE;
    }

    private boolean dndAllowsAlarm() {
        if (notificationManager == null) {
            return true;
        }
        int filter = notificationManager.getCurrentInterruptionFilter();
        if (filter == NotificationManager.INTERRUPTION_FILTER_ALL
                || filter == NotificationManager.INTERRUPTION_FILTER_ALARMS) {
            return true;
        }
        if (filter == NotificationManager.INTERRUPTION_FILTER_PRIORITY
                && notificationManager.isNotificationPolicyAccessGranted()) {
            NotificationManager.Policy policy = notificationManager.getNotificationPolicy();
            return (policy.priorityCategories & NotificationManager.Policy.PRIORITY_CATEGORY_ALARMS)
                    != 0;
        }
        return false;
    }

    private boolean canArm() {
        return hasFineLocationPermission()
                && isGpsEnabled()
                && soundTestConfirmed
                && notificationChannelsUsable()
                && alarmVolumeUsable()
                && dndAllowsAlarm()
                && !testOnly;
    }

    private boolean alarmVolumeUsable() {
        return audioManager != null
                && audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM) > 0
                && audioManager.getStreamVolume(AudioManager.STREAM_ALARM) > 0;
    }

    private void publishSnapshot() {
        if (preferences == null || routeEngine == null) {
            return;
        }
        try {
            JSONObject root = new JSONObject();
            root.put("serviceRunning", serviceRunning);
            root.put("armed", armed);
            root.put("armRequested", monitoringRequested);
            root.put("canArm", canArm());
            root.put("goodFixCount", goodFixCount);
            root.put("gpsStatus", gpsStatus);
            root.put("stage", stage);
            root.put("statusMessage", statusMessage);
            root.put("alarmActive", alarmActive);
            root.put("alarmKind", alarmKind);
            root.put("alarmAcknowledged", alarmAcknowledged);
            root.put("alarmSilencedUntilElapsedMs", alarmSilencedUntilElapsedMs);
            root.put("eventIndex", routeEngine.getEventIndex());
            root.put("eventCount", RouteEngine.EVENTS.size());
            root.put("routeComplete", routeEngine.getCurrentEvent() == null);
            root.put("updatedAtMs", System.currentTimeMillis());

            JSONObject permissions = new JSONObject();
            permissions.put("fineLocation", hasFineLocationPermission());
            permissions.put("notifications", notificationsAllowed());
            root.put("permissions", permissions);
            root.put("position", positionJson());
            root.put("evaluation", evaluationJson());
            root.put("event", eventJson(routeEngine.getCurrentEvent()));
            root.put("safety", safetyJson());

            preferences.edit().putString(KEY_SNAPSHOT_JSON, root.toString()).apply();
        } catch (JSONException ignored) {
            // All fields are primitive/local strings; this is only a defensive guard.
        }
    }

    private JSONObject positionJson() throws JSONException {
        JSONObject position = new JSONObject();
        if (lastSample == null) {
            position.put("available", false);
            return position;
        }
        position.put("available", true);
        position.put("latitude", lastSample.latitude);
        position.put("longitude", lastSample.longitude);
        position.put("latText", formatDegreesMinutes(lastSample.latitude, true));
        position.put("lonText", formatDegreesMinutes(lastSample.longitude, false));
        putFiniteOrNull(position, "accuracyM", lastSample.accuracyM);
        putFiniteOrNull(position, "speedKn", lastSample.speedKn);
        position.put(
                "ageMs",
                Math.max(0L, System.currentTimeMillis() - lastSample.timeMs));
        position.put("mock", lastSample.mock);
        position.put("timeMs", lastSample.timeMs);
        return position;
    }

    private JSONObject evaluationJson() throws JSONException {
        JSONObject evaluation = new JSONObject();
        if (lastEvaluation == null) {
            evaluation.put("distanceNm", JSONObject.NULL);
            evaluation.put("xteNm", JSONObject.NULL);
            evaluation.put("crossed", false);
            return evaluation;
        }
        putFiniteOrNull(evaluation, "distanceNm", lastEvaluation.distanceNm);
        putFiniteOrNull(evaluation, "xteNm", lastEvaluation.xteNm);
        evaluation.put("crossed", lastEvaluation.crossed);
        return evaluation;
    }

    private static Object eventJson(RouteEngine.Event event) throws JSONException {
        if (event == null) {
            return JSONObject.NULL;
        }
        JSONObject json = new JSONObject();
        json.put("id", event.id);
        json.put("title", event.title);
        json.put("station", event.station);
        json.put("channel", event.channel);
        json.put("action", event.action);
        json.put("note", event.note);
        json.put("mode", event.mode.name());
        json.put("targetSector", event.targetSector);
        return json;
    }

    private JSONObject safetyJson() throws JSONException {
        int alarmVolume = audioManager == null
                ? 0
                : audioManager.getStreamVolume(AudioManager.STREAM_ALARM);
        int alarmVolumeMax = audioManager == null
                ? 0
                : audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM);
        JSONObject safety = new JSONObject();
        safety.put("gpsEnabled", isGpsEnabled());
        safety.put("alarmVolume", alarmVolume);
        safety.put("alarmVolumeMax", alarmVolumeMax);
        safety.put("alarmVolumeUsable", alarmVolumeUsable());
        safety.put("dndAllowsAlarm", dndAllowsAlarm());
        safety.put("soundTestConfirmed", soundTestConfirmed);
        safety.put("notificationChannels", notificationChannelsUsable());
        return safety;
    }

    private static void putFiniteOrNull(JSONObject object, String key, double value)
            throws JSONException {
        object.put(key, Double.isFinite(value) ? value : JSONObject.NULL);
    }

    private static String formatDegreesMinutes(double value, boolean latitude) {
        String hemisphere = latitude
                ? (value >= 0.0 ? "N" : "S")
                : (value >= 0.0 ? "E" : "W");
        double absolute = Math.abs(value);
        int degrees = (int) Math.floor(absolute);
        double minutes = (absolute - degrees) * 60.0;
        return String.format(
                Locale.US,
                latitude ? "%02d\u00b0%06.3f\u2032%s" : "%03d\u00b0%06.3f\u2032%s",
                degrees,
                minutes,
                hemisphere);
    }
}

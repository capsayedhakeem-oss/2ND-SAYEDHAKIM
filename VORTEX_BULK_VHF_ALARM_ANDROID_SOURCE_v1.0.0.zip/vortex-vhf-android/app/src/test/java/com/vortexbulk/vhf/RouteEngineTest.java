package com.vortexbulk.vhf;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public final class RouteEngineTest {
    private static final double WESTERN_GATE_LON = 100.6666667;
    private static final double TEST_ACCURACY_M = 10.0;

    @Test
    public void verifiedEventContractIsExact() {
        assertEquals(4, RouteEngine.EVENTS.size());
        assertEvent(0, "western-entry", "KLANG VTS", "66", RouteEngine.Mode.MERIDIAN);
        assertEvent(1, "coa-iyu", "VTIS WEST", "73", RouteEngine.Mode.LANDMARK_ABEAM);
        assertEvent(2, "s6-s7", "VTIS WEST", "73", RouteEngine.Mode.SEGMENT);
        assertEvent(3, "s7-s8", "VTIS CENTRAL", "14", RouteEngine.Mode.MERIDIAN);

        RouteEngine.Event s6s7 = RouteEngine.EVENTS.get(2);
        assertEquals(1.2583333, s6s7.gateALat, 1e-7);
        assertEquals(103.5125, s6s7.gateALon, 1e-7);
        assertEquals(1.1533333, s6s7.gateBLat, 1e-7);
        assertEquals(103.4058333, s6s7.gateBLon, 1e-7);
        assertEquals(103.7416667, RouteEngine.EVENTS.get(3).cueLon, 1e-7);
    }

    @Test
    public void fixQualityRejectsMockStaleInaccurateAndFastSamples() {
        assertTrue(RouteEngine.sampleQualifies(sampleAtGate(0.0, 1_000L, false, 10.0, 12.0, 500L)));
        assertFalse(RouteEngine.sampleQualifies(sampleAtGate(0.0, 1_000L, true, 10.0, 12.0, 500L)));
        assertFalse(RouteEngine.sampleQualifies(sampleAtGate(0.0, 1_000L, false, 76.0, 12.0, 500L)));
        assertFalse(RouteEngine.sampleQualifies(sampleAtGate(0.0, 1_000L, false, 10.0, 31.0, 500L)));
        assertFalse(RouteEngine.sampleQualifies(sampleAtGate(0.0, 1_000L, false, 10.0, 12.0, 5_001L)));
    }

    @Test
    public void westernGateUsesFiveTwoAndHalfMileStages() {
        assertEquals("PREPARE", evaluateFirstFix(4.99).stage);
        assertEquals("STANDBY", evaluateFirstFix(1.99).stage);
        assertEquals("ACTION_DUE", evaluateFirstFix(0.49).stage);
        assertEquals("MONITOR", evaluateFirstFix(5.01).stage);
    }

    @Test
    public void crossingNeedsApproachAndThreeAcceptedPostGateFixes() {
        RouteEngine engine = new RouteEngine(0);
        RouteEngine.Sample approach = sampleAtGate(-0.25, 1_000L, false, 10.0, 12.0, 100L);
        assertTrue(engine.validateAndRecord(approach));
        assertFalse(engine.evaluate(approach, true).crossed);

        RouteEngine.Sample post1 = sampleAtGate(0.25, 62_000L, false, 10.0, 12.0, 100L);
        assertTrue(engine.validateAndRecord(post1));
        assertFalse(engine.evaluate(post1, true).crossed);

        RouteEngine.Sample post2 = sampleAtGate(0.25, 63_000L, false, 10.0, 12.0, 100L);
        assertTrue(engine.validateAndRecord(post2));
        assertFalse(engine.evaluate(post2, true).crossed);

        RouteEngine.Sample post3 = sampleAtGate(0.25, 64_000L, false, 10.0, 12.0, 100L);
        assertTrue(engine.validateAndRecord(post3));
        RouteEngine.Evaluation result = engine.evaluate(post3, true);
        assertTrue(result.crossed);
        assertEquals("CROSSED_WAITING_ACK", result.stage);
        assertEquals(0, engine.getEventIndex());

        engine.completeCurrentEvent();
        assertEquals(1, engine.getEventIndex());
    }

    @Test
    public void startingAheadNeverSilentlyCompletesTheCall() {
        RouteEngine engine = new RouteEngine(0);
        RouteEngine.Sample alreadyAhead = sampleAtGate(0.30, 1_000L, false, 10.0, 12.0, 100L);
        assertTrue(engine.validateAndRecord(alreadyAhead));
        RouteEngine.Evaluation result = engine.evaluate(alreadyAhead, true);
        assertEquals("AHEAD_CONFIRM", result.stage);
        assertFalse(result.crossed);
        assertEquals(0, engine.getEventIndex());
    }

    @Test
    public void offCorridorNearGateFreezesAutomaticCue() {
        RouteEngine engine = new RouteEngine(0);
        RouteEngine.Sample offRoute = new RouteEngine.Sample(
                4.0,
                WESTERN_GATE_LON - nmToLongitudeDegrees(4.0, 4.0),
                TEST_ACCURACY_M,
                12.0,
                100L,
                1_000L,
                false);
        assertTrue(engine.validateAndRecord(offRoute));
        RouteEngine.Evaluation result = engine.evaluate(offRoute, true);
        assertEquals("ROUTE_MISMATCH", result.stage);
        assertTrue(result.xteNm > RouteEngine.ROUTE_CORRIDOR_NM);
        assertFalse(result.crossed);
    }

    private static RouteEngine.Evaluation evaluateFirstFix(double milesBeforeGate) {
        RouteEngine engine = new RouteEngine(0);
        RouteEngine.Sample sample = sampleAtGate(
                -milesBeforeGate,
                1_000L,
                false,
                TEST_ACCURACY_M,
                12.0,
                100L);
        boolean accepted = engine.validateAndRecord(sample);
        assertTrue(accepted);
        return engine.evaluate(sample, accepted);
    }

    private static RouteEngine.Sample sampleAtGate(
            double signedDistanceNm,
            long timeMs,
            boolean mock,
            double accuracyM,
            double speedKn,
            long ageMs) {
        RouteEngine.Event event = RouteEngine.EVENTS.get(0);
        double longitude = WESTERN_GATE_LON
                + nmToLongitudeDegrees(signedDistanceNm, event.cueLat);
        double routeFraction = (longitude - event.routeStartLon)
                / (event.routeEndLon - event.routeStartLon);
        double latitude = event.routeStartLat
                + routeFraction * (event.routeEndLat - event.routeStartLat);
        return new RouteEngine.Sample(
                latitude,
                longitude,
                accuracyM,
                speedKn,
                ageMs,
                timeMs,
                mock);
    }

    private static double nmToLongitudeDegrees(double distanceNm, double latitude) {
        return distanceNm / (60.0 * Math.cos(Math.toRadians(latitude)));
    }

    private static void assertEvent(
            int index,
            String id,
            String station,
            String channel,
            RouteEngine.Mode mode) {
        RouteEngine.Event event = RouteEngine.EVENTS.get(index);
        assertEquals(id, event.id);
        assertEquals(station, event.station);
        assertEquals(channel, event.channel);
        assertEquals(mode, event.mode);
    }
}
